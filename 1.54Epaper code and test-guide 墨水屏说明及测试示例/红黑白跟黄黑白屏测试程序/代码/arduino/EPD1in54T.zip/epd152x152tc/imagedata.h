#ifndef _IMAGE_H_
#define _IMAGE_H_

extern const unsigned char IMAGE_BLACK[];
extern const unsigned char IMAGE_YELLOW[];

#endif
